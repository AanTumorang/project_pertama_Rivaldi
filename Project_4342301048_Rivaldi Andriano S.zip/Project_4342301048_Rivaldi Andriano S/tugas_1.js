function submited(){
    let nisn = document.getElementById('nisn');
    let name = document.getElementById('name');
    let l = document.getElementById('kelaminl');
    let p = document.getElementById('kelaminp');
    let ttl = document.getElementById('ttl');
    let agama = document.getElementById('agama');
    let anakke = document.getElementById('anakke');
    let jsaudara = document.getElementById('j_saudara');
    
    if (nisn.value == ''){
        alert('nisn wajib di isi');
        nisn.focus();
        return false;
    }
    if (name.value == ''){
        alert('nama wajib di isi');
        name.focus();
        return false;
    }
    if (ttl.value == ''){
        alert('TTL wajib di isi');
        ttl.focus();
        return false;
    }
    kelamin = assignKelamin(l,p)
    if (agama.value == ''){
        alert('agama wajib di isi');
        agama.focus();
        return false;
    }
    if (anakke.value == ''){
        alert('anak-ke wajib di isi');
        anakke.focus();
        return false;
    }
    if (jsaudara.value == ''){
        alert('jumlah saudara wajib di isi');
        jsaudara.focus();
        return false;
    }
    console.log({
        name: name.value,
        nisn: nisn.value,
        kelamin: kelamin,
        ttl: ttl.value,
        agama: agama.value,
        ankke: anakke.value,
        jsaudara: jsaudara.value
    })
    showNextTable()
    
}

function assignKelamin(l,p){
    let kelamin
    if (l.checked){
        kelamin = l.value
        console.log(l.value)
    } 
    else if (p.checked){
        kelamin = p.value
        console.log(p.value)
    }
    else {
        alert('kelaminmu ga ada')
        kelamin = false
    }
    return kelamin
}

function showNextTable(){
    let docs = document.querySelector('.hidden').classList.remove('hidden')
}

function resetButton(){
    let nisn = document.getElementById('nisn');
    let name = document.getElementById('name');
    let l = document.getElementById('kelaminl');
    let p = document.getElementById('kelaminp');
    let ttl = document.getElementById('ttl');
    let agama = document.getElementById('agama');
    let anakke = document.getElementById('anakke');
    let jsaudara = document.getElementById('j_saudara');
    nisn.value = ''
    name.value = ''
    l.checked = false
    p.checked = false
    ttl.value = ''
    agama.value = ''
    anakke.value = ''
    jsaudara.value = ''
    // console.log()
}